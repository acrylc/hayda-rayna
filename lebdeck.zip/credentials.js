/* Credentials for nTwitter
 * Fields are consumer_key, consumer_secret, access_token_key, access_token_secret
 */
module.exports = {
	consumer_key: "B1T2DEXKqCZKjdHH2O5A",
	consumer_secret: "8nvp0lI5tcyV319O3fk6qgSTZz6crfrbKvxgUupYPY",
	access_token_key: "14206428-buxH1hDSAPMfoFusdRm2mJOMyUdqz9Xiu9Vgnvz1V",
	access_token_secret: "eNaHxlU8uqp3zHPIqyWmMqqK5zoGp8wlzehoH2w4HnpP8"
}