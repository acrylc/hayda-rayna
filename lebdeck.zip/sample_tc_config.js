var topcap_config = {
	scriptURL = ""
}

module.exports = topcap_config