var topcap_config = {
	scriptURL: "https://script.google.com/macros/s/" + 
		"AKfycbxOzcwL7K0JiVchhqylLvB0AAi7YiSBQAQ7DMB6SfYY9xG2mYs/exec"
}

module.exports = topcap_config