/* Credentials of the App registered on Twitter API, http://dev.twitter.com
 * Fields are consumer_key, consumer_secret, access_token_key, access_token_secret
 */
module.exports = {
	consumer_key: "CONSUMER_KEY",
	consumer_secret: "CONSUMER_SECRET",
	access_token_key: "ACCESS_TOKEN_KEY",
	access_token_secret: ""
}